package br.cesed.unifacisa.si.pp.projeto.MontApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MontAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MontAppApplication.class, args);
	}

}
